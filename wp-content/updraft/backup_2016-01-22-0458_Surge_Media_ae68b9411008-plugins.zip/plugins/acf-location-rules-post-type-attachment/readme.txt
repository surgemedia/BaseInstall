=== ACF Location Rules Post Type Attachment ===
Contributors: Fastmover
Donate link: http://www.kcpt.org/
Tags: acf, advanced custom fields, post_type attachment, attachment
Requires at least: 3.5
Tested up to: 4.1
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to add attachment back as an option in Post Types under Location Rules.

== Description ==

This plugin came about as a need to negate the attachment page for advanced custom fields.  With enough post types on a website, it's easier to negate the post types you don't want fields showing up on, rather than selecting all the post types you want the fields to show up on.

== Installation ==

1. Unzip files.
2. Upload the folder into your plugins directory.
3. Activate the plugin.
4. Have fun!

== Screenshots ==

1. Post Type is not equal to attachment

== Changelog ==

= 0.0.1 =
* Initial Version